﻿namespace Medley_Car_Care
{
    partial class Billing
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Billing));
            Syncfusion.Windows.Forms.MetroColorTable metroColorTable1 = new Syncfusion.Windows.Forms.MetroColorTable();
            panel1 = new Panel();
            panel22 = new Panel();
            CalculatorButton = new Button();
            PrintInvoice = new Syncfusion.Windows.Forms.Tools.CheckBoxAdv();
            JazzCashCheck = new Syncfusion.Windows.Forms.Tools.CheckBoxAdv();
            ATMText = new Syncfusion.Windows.Forms.Tools.CheckBoxAdv();
            Credit = new Syncfusion.Windows.Forms.Tools.CheckBoxAdv();
            ModeOfPaymentText = new Syncfusion.Windows.Forms.Tools.AutoLabel();
            CashCheck = new Syncfusion.Windows.Forms.Tools.CheckBoxAdv();
            CheckoutButton = new Button();
            BalanceBox = new TextBox();
            BalanceText = new Label();
            ReceivedBox = new TextBox();
            RecievedText = new Label();
            NetAmountBox = new TextBox();
            NetAmountText = new Label();
            DiscountBox = new TextBox();
            DiscountText = new Label();
            TotalAmountBox = new TextBox();
            TotalAmountText = new Label();
            tableLayoutPanel1 = new TableLayoutPanel();
            panel12 = new Panel();
            TotalPriceText = new Label();
            panel11 = new Panel();
            PricePerUnitText = new Label();
            panel10 = new Panel();
            QuantityPerUnitText = new Label();
            panel9 = new Panel();
            QuantityinStock = new Label();
            panel8 = new Panel();
            ProductName = new Label();
            panel7 = new Panel();
            hashText = new Label();
            panel6 = new Panel();
            BarcodeText = new Label();
            editableList1 = new Syncfusion.Windows.Forms.Tools.EditableList();
            panel5 = new Panel();
            additemtotable = new Button();
            qtylable = new Label();
            itemquantity = new TextBox();
            ProductNameText = new Label();
            ProductNameBox = new TextBox();
            ProductBarcodeText = new Label();
            ProductBarcodeBox = new TextBox();
            panel4 = new Panel();
            SearchCustomerButton = new Button();
            PrevBalanaceText = new Label();
            PrevBalanceBox = new TextBox();
            CellNumberText = new Label();
            textBox2 = new TextBox();
            CustomerNameText = new Label();
            textBox4 = new TextBox();
            panel3 = new Panel();
            WorkerNameText = new Label();
            WorkerNameBox = new TextBox();
            DueMileageText = new Label();
            textBox3 = new TextBox();
            CuurentMileageText = new Label();
            CurrentMileageBox = new TextBox();
            OilMileageText = new Label();
            OilMileageBox = new TextBox();
            panel2 = new Panel();
            VehicleSearchButton = new Button();
            label1 = new Label();
            VehicleSearchBox = new TextBox();
            tableLayoutPanel2 = new TableLayoutPanel();
            panel1.SuspendLayout();
            panel22.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)PrintInvoice).BeginInit();
            ((System.ComponentModel.ISupportInitialize)JazzCashCheck).BeginInit();
            ((System.ComponentModel.ISupportInitialize)ATMText).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Credit).BeginInit();
            ((System.ComponentModel.ISupportInitialize)CashCheck).BeginInit();
            tableLayoutPanel1.SuspendLayout();
            panel12.SuspendLayout();
            panel11.SuspendLayout();
            panel10.SuspendLayout();
            panel9.SuspendLayout();
            panel8.SuspendLayout();
            panel7.SuspendLayout();
            panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)editableList1.TextBox).BeginInit();
            panel5.SuspendLayout();
            panel4.SuspendLayout();
            panel3.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.GhostWhite;
            panel1.Controls.Add(panel22);
            panel1.Controls.Add(tableLayoutPanel1);
            panel1.Controls.Add(panel5);
            panel1.Controls.Add(panel4);
            panel1.Controls.Add(panel3);
            panel1.Controls.Add(panel2);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1676, 916);
            panel1.TabIndex = 0;
            // 
            // panel22
            // 
            panel22.BackColor = Color.SkyBlue;
            panel22.Controls.Add(CalculatorButton);
            panel22.Controls.Add(PrintInvoice);
            panel22.Controls.Add(JazzCashCheck);
            panel22.Controls.Add(ATMText);
            panel22.Controls.Add(Credit);
            panel22.Controls.Add(ModeOfPaymentText);
            panel22.Controls.Add(CashCheck);
            panel22.Controls.Add(CheckoutButton);
            panel22.Controls.Add(BalanceBox);
            panel22.Controls.Add(BalanceText);
            panel22.Controls.Add(ReceivedBox);
            panel22.Controls.Add(RecievedText);
            panel22.Controls.Add(NetAmountBox);
            panel22.Controls.Add(NetAmountText);
            panel22.Controls.Add(DiscountBox);
            panel22.Controls.Add(DiscountText);
            panel22.Controls.Add(TotalAmountBox);
            panel22.Controls.Add(TotalAmountText);
            panel22.Dock = DockStyle.Bottom;
            panel22.Location = new Point(0, 731);
            panel22.Name = "panel22";
            panel22.Size = new Size(1676, 185);
            panel22.TabIndex = 5;
            // 
            // CalculatorButton
            // 
            CalculatorButton.BackColor = Color.SkyBlue;
            CalculatorButton.BackgroundImage = (Image)resources.GetObject("CalculatorButton.BackgroundImage");
            CalculatorButton.BackgroundImageLayout = ImageLayout.None;
            CalculatorButton.FlatAppearance.BorderSize = 0;
            CalculatorButton.FlatStyle = FlatStyle.Flat;
            CalculatorButton.Location = new Point(1571, 19);
            CalculatorButton.Name = "CalculatorButton";
            CalculatorButton.Size = new Size(54, 53);
            CalculatorButton.TabIndex = 17;
            CalculatorButton.UseVisualStyleBackColor = false;
            CalculatorButton.Click += CalculatorButton_Click;
            // 
            // PrintInvoice
            // 
            PrintInvoice.AccessibilityEnabled = true;
            PrintInvoice.BeforeTouchSize = new Size(135, 34);
            PrintInvoice.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            PrintInvoice.Location = new Point(1247, 112);
            PrintInvoice.Name = "PrintInvoice";
            PrintInvoice.Size = new Size(135, 34);
            PrintInvoice.TabIndex = 16;
            PrintInvoice.Text = "Print Invoice";
            // 
            // JazzCashCheck
            // 
            JazzCashCheck.AccessibilityEnabled = true;
            JazzCashCheck.BeforeTouchSize = new Size(96, 34);
            JazzCashCheck.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            JazzCashCheck.Location = new Point(417, 112);
            JazzCashCheck.Name = "JazzCashCheck";
            JazzCashCheck.Size = new Size(96, 34);
            JazzCashCheck.TabIndex = 15;
            JazzCashCheck.Text = "Jazz Cash";
            JazzCashCheck.CheckStateChanged += JazzCashCheck_CheckStateChanged;
            // 
            // ATMText
            // 
            ATMText.AccessibilityEnabled = true;
            ATMText.BeforeTouchSize = new Size(77, 34);
            ATMText.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ATMText.Location = new Point(334, 112);
            ATMText.Name = "ATMText";
            ATMText.Size = new Size(77, 34);
            ATMText.TabIndex = 14;
            ATMText.Text = "ATM";
            ATMText.CheckStateChanged += ATMText_CheckStateChanged;
            // 
            // Credit
            // 
            Credit.AccessibilityEnabled = true;
            Credit.BeforeTouchSize = new Size(77, 34);
            Credit.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Credit.Location = new Point(251, 112);
            Credit.Name = "Credit";
            Credit.Size = new Size(77, 34);
            Credit.TabIndex = 13;
            Credit.Text = "Credit";
            Credit.CheckStateChanged += Credit_CheckStateChanged;
            // 
            // ModeOfPaymentText
            // 
            ModeOfPaymentText.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ModeOfPaymentText.Location = new Point(12, 112);
            ModeOfPaymentText.Name = "ModeOfPaymentText";
            ModeOfPaymentText.Size = new Size(145, 21);
            ModeOfPaymentText.TabIndex = 12;
            ModeOfPaymentText.Text = "Mode of Payment:";
            // 
            // CashCheck
            // 
            CashCheck.AccessibilityEnabled = true;
            CashCheck.BeforeTouchSize = new Size(77, 34);
            CashCheck.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            CashCheck.Location = new Point(168, 112);
            CashCheck.Name = "CashCheck";
            CashCheck.Size = new Size(77, 34);
            CashCheck.TabIndex = 11;
            CashCheck.Text = "Cash";
            CashCheck.CheckStateChanged += CashCheck_CheckStateChanged;
            // 
            // CheckoutButton
            // 
            CheckoutButton.BackColor = Color.CornflowerBlue;
            CheckoutButton.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            CheckoutButton.Location = new Point(1428, 81);
            CheckoutButton.Name = "CheckoutButton";
            CheckoutButton.Size = new Size(207, 73);
            CheckoutButton.TabIndex = 10;
            CheckoutButton.Text = "Checkout";
            CheckoutButton.UseVisualStyleBackColor = false;
            CheckoutButton.Click += CheckoutButton_Click;
            // 
            // BalanceBox
            // 
            BalanceBox.Font = new Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            BalanceBox.Location = new Point(1333, 19);
            BalanceBox.Name = "BalanceBox";
            BalanceBox.ReadOnly = true;
            BalanceBox.Size = new Size(153, 43);
            BalanceBox.TabIndex = 9;
            // 
            // BalanceText
            // 
            BalanceText.AutoSize = true;
            BalanceText.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            BalanceText.Location = new Point(1247, 32);
            BalanceText.Name = "BalanceText";
            BalanceText.Size = new Size(80, 25);
            BalanceText.TabIndex = 8;
            BalanceText.Text = "Balance";
            // 
            // ReceivedBox
            // 
            ReceivedBox.Font = new Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            ReceivedBox.Location = new Point(1054, 19);
            ReceivedBox.Name = "ReceivedBox";
            ReceivedBox.Size = new Size(153, 43);
            ReceivedBox.TabIndex = 7;
            ReceivedBox.TextChanged += ReceivedBox_TextChanged;
            // 
            // RecievedText
            // 
            RecievedText.AutoSize = true;
            RecievedText.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            RecievedText.Location = new Point(958, 32);
            RecievedText.Name = "RecievedText";
            RecievedText.Size = new Size(90, 25);
            RecievedText.TabIndex = 6;
            RecievedText.Text = "Received";
            // 
            // NetAmountBox
            // 
            NetAmountBox.Font = new Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            NetAmountBox.Location = new Point(765, 19);
            NetAmountBox.Name = "NetAmountBox";
            NetAmountBox.ReadOnly = true;
            NetAmountBox.Size = new Size(153, 43);
            NetAmountBox.TabIndex = 5;
            NetAmountBox.TextChanged += NetAmountBox_TextChanged;
            // 
            // NetAmountText
            // 
            NetAmountText.AutoSize = true;
            NetAmountText.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            NetAmountText.Location = new Point(637, 32);
            NetAmountText.Name = "NetAmountText";
            NetAmountText.Size = new Size(122, 25);
            NetAmountText.TabIndex = 4;
            NetAmountText.Text = "Net Amount";
            // 
            // DiscountBox
            // 
            DiscountBox.Font = new Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            DiscountBox.Location = new Point(444, 19);
            DiscountBox.Name = "DiscountBox";
            DiscountBox.Size = new Size(153, 43);
            DiscountBox.TabIndex = 3;
            DiscountBox.TextChanged += DiscountBox_TextChanged;
            // 
            // DiscountText
            // 
            DiscountText.AutoSize = true;
            DiscountText.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            DiscountText.Location = new Point(347, 32);
            DiscountText.Name = "DiscountText";
            DiscountText.Size = new Size(91, 25);
            DiscountText.TabIndex = 2;
            DiscountText.Text = "Discount";
            // 
            // TotalAmountBox
            // 
            TotalAmountBox.Font = new Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            TotalAmountBox.Location = new Point(154, 19);
            TotalAmountBox.Name = "TotalAmountBox";
            TotalAmountBox.Size = new Size(153, 43);
            TotalAmountBox.TabIndex = 1;
            TotalAmountBox.TextChanged += TotalAmountBox_TextChanged;
            // 
            // TotalAmountText
            // 
            TotalAmountText.AutoSize = true;
            TotalAmountText.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            TotalAmountText.Location = new Point(15, 32);
            TotalAmountText.Name = "TotalAmountText";
            TotalAmountText.Size = new Size(133, 25);
            TotalAmountText.TabIndex = 0;
            TotalAmountText.Text = "Total Amount";
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.BackColor = Color.GhostWhite;
            tableLayoutPanel1.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel1.ColumnCount = 8;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 2.86812F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 6.087437F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 39.71144F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 12.23341F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 12.233243F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 12.233243F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 12.233243F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 2.39985514F));
            tableLayoutPanel1.Controls.Add(panel12, 6, 0);
            tableLayoutPanel1.Controls.Add(panel11, 5, 0);
            tableLayoutPanel1.Controls.Add(panel10, 4, 0);
            tableLayoutPanel1.Controls.Add(panel9, 3, 0);
            tableLayoutPanel1.Controls.Add(panel8, 2, 0);
            tableLayoutPanel1.Controls.Add(panel7, 0, 0);
            tableLayoutPanel1.Controls.Add(panel6, 1, 0);
            tableLayoutPanel1.Controls.Add(editableList1, 1, 1);
            tableLayoutPanel1.Location = new Point(0, 208);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 24;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 5.23475266F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.120299F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.120299F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.120299F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.120299F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.120299F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.120299F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.120299F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.120299F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.120299F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.120299F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.120299F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.120299F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.120299F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.120299F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.120299F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.120299F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.120299F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.120299F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.12029839F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.119887F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.119887F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.119887F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.119887F));
            tableLayoutPanel1.Size = new Size(1677, 526);
            tableLayoutPanel1.TabIndex = 4;
            tableLayoutPanel1.Paint += tableLayoutPanel1_Paint;
            // 
            // panel12
            // 
            panel12.BackColor = Color.SkyBlue;
            panel12.Controls.Add(TotalPriceText);
            panel12.Dock = DockStyle.Fill;
            panel12.Location = new Point(1432, 4);
            panel12.Name = "panel12";
            panel12.Size = new Size(198, 20);
            panel12.TabIndex = 6;
            // 
            // TotalPriceText
            // 
            TotalPriceText.AutoSize = true;
            TotalPriceText.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            TotalPriceText.Location = new Point(64, 2);
            TotalPriceText.Name = "TotalPriceText";
            TotalPriceText.Size = new Size(82, 20);
            TotalPriceText.TabIndex = 1;
            TotalPriceText.Text = "Total Price";
            TotalPriceText.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panel11
            // 
            panel11.BackColor = Color.SkyBlue;
            panel11.Controls.Add(PricePerUnitText);
            panel11.Dock = DockStyle.Fill;
            panel11.Location = new Point(1227, 4);
            panel11.Name = "panel11";
            panel11.Size = new Size(198, 20);
            panel11.TabIndex = 5;
            // 
            // PricePerUnitText
            // 
            PricePerUnitText.AutoSize = true;
            PricePerUnitText.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            PricePerUnitText.Location = new Point(54, 2);
            PricePerUnitText.Name = "PricePerUnitText";
            PricePerUnitText.Size = new Size(104, 20);
            PricePerUnitText.TabIndex = 1;
            PricePerUnitText.Text = "Price Per Unit";
            PricePerUnitText.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panel10
            // 
            panel10.BackColor = Color.SkyBlue;
            panel10.Controls.Add(QuantityPerUnitText);
            panel10.Dock = DockStyle.Fill;
            panel10.Location = new Point(1022, 4);
            panel10.Name = "panel10";
            panel10.Size = new Size(198, 20);
            panel10.TabIndex = 4;
            // 
            // QuantityPerUnitText
            // 
            QuantityPerUnitText.AutoSize = true;
            QuantityPerUnitText.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            QuantityPerUnitText.Location = new Point(36, 2);
            QuantityPerUnitText.Name = "QuantityPerUnitText";
            QuantityPerUnitText.Size = new Size(131, 20);
            QuantityPerUnitText.TabIndex = 1;
            QuantityPerUnitText.Text = "Quantity Per Unit";
            QuantityPerUnitText.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panel9
            // 
            panel9.BackColor = Color.SkyBlue;
            panel9.Controls.Add(QuantityinStock);
            panel9.Dock = DockStyle.Fill;
            panel9.Location = new Point(817, 4);
            panel9.Name = "panel9";
            panel9.Size = new Size(198, 20);
            panel9.TabIndex = 3;
            // 
            // QuantityinStock
            // 
            QuantityinStock.AutoSize = true;
            QuantityinStock.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            QuantityinStock.Location = new Point(29, 1);
            QuantityinStock.Name = "QuantityinStock";
            QuantityinStock.Size = new Size(129, 20);
            QuantityinStock.TabIndex = 1;
            QuantityinStock.Text = "Quantity in Stock";
            QuantityinStock.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panel8
            // 
            panel8.BackColor = Color.SkyBlue;
            panel8.Controls.Add(ProductName);
            panel8.Dock = DockStyle.Fill;
            panel8.Location = new Point(154, 4);
            panel8.Name = "panel8";
            panel8.Size = new Size(656, 20);
            panel8.TabIndex = 2;
            // 
            // ProductName
            // 
            ProductName.AutoSize = true;
            ProductName.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ProductName.Location = new Point(273, 1);
            ProductName.Name = "ProductName";
            ProductName.Size = new Size(110, 20);
            ProductName.TabIndex = 1;
            ProductName.Text = "Product Name";
            ProductName.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panel7
            // 
            panel7.BackColor = Color.SkyBlue;
            panel7.Controls.Add(hashText);
            panel7.Dock = DockStyle.Fill;
            panel7.Location = new Point(4, 4);
            panel7.Name = "panel7";
            panel7.Size = new Size(41, 20);
            panel7.TabIndex = 1;
            // 
            // hashText
            // 
            hashText.AutoSize = true;
            hashText.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            hashText.Location = new Point(12, 1);
            hashText.Name = "hashText";
            hashText.Padding = new Padding(0, 0, 10, 0);
            hashText.Size = new Size(29, 21);
            hashText.TabIndex = 1;
            hashText.Text = "#";
            hashText.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panel6
            // 
            panel6.BackColor = Color.SkyBlue;
            panel6.Controls.Add(BarcodeText);
            panel6.Dock = DockStyle.Fill;
            panel6.Location = new Point(52, 4);
            panel6.Name = "panel6";
            panel6.Size = new Size(95, 20);
            panel6.TabIndex = 0;
            // 
            // BarcodeText
            // 
            BarcodeText.AutoSize = true;
            BarcodeText.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            BarcodeText.Location = new Point(16, 1);
            BarcodeText.Name = "BarcodeText";
            BarcodeText.Size = new Size(66, 20);
            BarcodeText.TabIndex = 0;
            BarcodeText.Text = "Barcode";
            BarcodeText.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // editableList1
            // 
            editableList1.BackColor = Color.Transparent;
            editableList1.BeforeTouchSize = new Size(95, 14);
            // 
            // 
            // 
            editableList1.Button.FlatStyle = FlatStyle.Popup;
            editableList1.Button.Location = new Point(112, 120);
            editableList1.Button.Name = "button";
            editableList1.Button.Size = new Size(30, 20);
            editableList1.Button.TabIndex = 2;
            editableList1.Button.Text = "...";
            editableList1.Button.Visible = false;
            // 
            // 
            // 
            editableList1.ListBox.Dock = DockStyle.Fill;
            editableList1.ListBox.DrawMode = DrawMode.OwnerDrawFixed;
            editableList1.ListBox.Location = new Point(0, 0);
            editableList1.ListBox.Name = "listBox";
            editableList1.ListBox.Size = new Size(95, 4);
            editableList1.ListBox.TabIndex = 0;
            editableList1.Location = new Point(52, 31);
            editableList1.Name = "editableList1";
            editableList1.ScrollMetroColorTable = metroColorTable1;
            editableList1.Size = new Size(95, 14);
            editableList1.TabIndex = 7;
            // 
            // 
            // 
            editableList1.TextBox.BeforeTouchSize = new Size(100, 23);
            editableList1.TextBox.BorderStyle = BorderStyle.FixedSingle;
            editableList1.TextBox.Location = new Point(8, 120);
            editableList1.TextBox.Name = "textBox";
            editableList1.TextBox.TabIndex = 2;
            editableList1.TextBox.Visible = false;
            editableList1.Load += editableList1_Load;
            // 
            // panel5
            // 
            panel5.BackColor = Color.SkyBlue;
            panel5.Controls.Add(additemtotable);
            panel5.Controls.Add(qtylable);
            panel5.Controls.Add(itemquantity);
            panel5.Controls.Add(ProductNameText);
            panel5.Controls.Add(ProductNameBox);
            panel5.Controls.Add(ProductBarcodeText);
            panel5.Controls.Add(ProductBarcodeBox);
            panel5.Location = new Point(0, 155);
            panel5.Name = "panel5";
            panel5.Size = new Size(1676, 47);
            panel5.TabIndex = 3;
            panel5.Paint += panel5_Paint;
            // 
            // additemtotable
            // 
            additemtotable.BackColor = Color.CornflowerBlue;
            additemtotable.FlatAppearance.BorderSize = 0;
            additemtotable.FlatStyle = FlatStyle.Flat;
            additemtotable.Font = new Font("Segoe UI Semibold", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            additemtotable.Location = new Point(1415, 9);
            additemtotable.Name = "additemtotable";
            additemtotable.Size = new Size(109, 24);
            additemtotable.TabIndex = 15;
            additemtotable.Text = "ADD";
            additemtotable.UseVisualStyleBackColor = false;
            additemtotable.Click += additemtotable_Click;
            // 
            // qtylable
            // 
            qtylable.AutoSize = true;
            qtylable.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            qtylable.Location = new Point(1122, 13);
            qtylable.Name = "qtylable";
            qtylable.Size = new Size(62, 17);
            qtylable.TabIndex = 5;
            qtylable.Text = "Quantity";
            // 
            // itemquantity
            // 
            itemquantity.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            itemquantity.Location = new Point(1224, 8);
            itemquantity.Name = "itemquantity";
            itemquantity.Size = new Size(128, 27);
            itemquantity.TabIndex = 4;
            // 
            // ProductNameText
            // 
            ProductNameText.AutoSize = true;
            ProductNameText.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ProductNameText.Location = new Point(366, 13);
            ProductNameText.Name = "ProductNameText";
            ProductNameText.Size = new Size(96, 17);
            ProductNameText.TabIndex = 3;
            ProductNameText.Text = "Product Name";
            // 
            // ProductNameBox
            // 
            ProductNameBox.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            ProductNameBox.Location = new Point(468, 8);
            ProductNameBox.Name = "ProductNameBox";
            ProductNameBox.Size = new Size(505, 27);
            ProductNameBox.TabIndex = 2;
            ProductNameBox.TextChanged += ProductNameBox_TextChanged;
            // 
            // ProductBarcodeText
            // 
            ProductBarcodeText.AutoSize = true;
            ProductBarcodeText.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ProductBarcodeText.Location = new Point(12, 13);
            ProductBarcodeText.Name = "ProductBarcodeText";
            ProductBarcodeText.Size = new Size(109, 17);
            ProductBarcodeText.TabIndex = 1;
            ProductBarcodeText.Text = "Product Barcode";
            // 
            // ProductBarcodeBox
            // 
            ProductBarcodeBox.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            ProductBarcodeBox.Location = new Point(127, 8);
            ProductBarcodeBox.Name = "ProductBarcodeBox";
            ProductBarcodeBox.Size = new Size(157, 27);
            ProductBarcodeBox.TabIndex = 0;
            ProductBarcodeBox.TextChanged += ProductBarcodeBox_TextChanged;
            // 
            // panel4
            // 
            panel4.BackColor = Color.SkyBlue;
            panel4.Controls.Add(SearchCustomerButton);
            panel4.Controls.Add(PrevBalanaceText);
            panel4.Controls.Add(PrevBalanceBox);
            panel4.Controls.Add(CellNumberText);
            panel4.Controls.Add(textBox2);
            panel4.Controls.Add(CustomerNameText);
            panel4.Controls.Add(textBox4);
            panel4.Location = new Point(0, 102);
            panel4.Name = "panel4";
            panel4.Size = new Size(1676, 47);
            panel4.TabIndex = 2;
            // 
            // SearchCustomerButton
            // 
            SearchCustomerButton.BackColor = Color.CornflowerBlue;
            SearchCustomerButton.FlatAppearance.BorderSize = 0;
            SearchCustomerButton.FlatStyle = FlatStyle.Flat;
            SearchCustomerButton.Font = new Font("Segoe UI Semibold", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            SearchCustomerButton.Location = new Point(679, 10);
            SearchCustomerButton.Name = "SearchCustomerButton";
            SearchCustomerButton.Size = new Size(130, 24);
            SearchCustomerButton.TabIndex = 14;
            SearchCustomerButton.Text = "Search Customer";
            SearchCustomerButton.UseVisualStyleBackColor = false;
            SearchCustomerButton.Click += SearchCustomerButton_Click;
            // 
            // PrevBalanaceText
            // 
            PrevBalanaceText.AutoSize = true;
            PrevBalanaceText.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            PrevBalanaceText.Location = new Point(929, 14);
            PrevBalanaceText.Name = "PrevBalanaceText";
            PrevBalanaceText.Size = new Size(112, 17);
            PrevBalanaceText.TabIndex = 13;
            PrevBalanaceText.Text = "Previous Balance";
            // 
            // PrevBalanceBox
            // 
            PrevBalanceBox.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            PrevBalanceBox.Location = new Point(1047, 9);
            PrevBalanceBox.Name = "PrevBalanceBox";
            PrevBalanceBox.Size = new Size(129, 27);
            PrevBalanceBox.TabIndex = 12;
            // 
            // CellNumberText
            // 
            CellNumberText.AutoSize = true;
            CellNumberText.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            CellNumberText.Location = new Point(397, 14);
            CellNumberText.Name = "CellNumberText";
            CellNumberText.Size = new Size(57, 17);
            CellNumberText.TabIndex = 11;
            CellNumberText.Text = "Cell No.";
            // 
            // textBox2
            // 
            textBox2.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox2.Location = new Point(460, 9);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(198, 27);
            textBox2.TabIndex = 10;
            textBox2.TextChanged += textBox2_TextChanged;
            // 
            // CustomerNameText
            // 
            CustomerNameText.AutoSize = true;
            CustomerNameText.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            CustomerNameText.Location = new Point(12, 14);
            CustomerNameText.Name = "CustomerNameText";
            CustomerNameText.Size = new Size(107, 17);
            CustomerNameText.TabIndex = 9;
            CustomerNameText.Text = "Customer Name";
            // 
            // textBox4
            // 
            textBox4.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox4.Location = new Point(125, 9);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(216, 27);
            textBox4.TabIndex = 8;
            // 
            // panel3
            // 
            panel3.BackColor = Color.SkyBlue;
            panel3.Controls.Add(WorkerNameText);
            panel3.Controls.Add(WorkerNameBox);
            panel3.Controls.Add(DueMileageText);
            panel3.Controls.Add(textBox3);
            panel3.Controls.Add(CuurentMileageText);
            panel3.Controls.Add(CurrentMileageBox);
            panel3.Controls.Add(OilMileageText);
            panel3.Controls.Add(OilMileageBox);
            panel3.Location = new Point(0, 51);
            panel3.Margin = new Padding(0);
            panel3.Name = "panel3";
            panel3.Size = new Size(1676, 47);
            panel3.TabIndex = 1;
            // 
            // WorkerNameText
            // 
            WorkerNameText.AutoSize = true;
            WorkerNameText.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            WorkerNameText.Location = new Point(1307, 15);
            WorkerNameText.Name = "WorkerNameText";
            WorkerNameText.Size = new Size(93, 17);
            WorkerNameText.TabIndex = 9;
            WorkerNameText.Text = "Worker Name";
            // 
            // WorkerNameBox
            // 
            WorkerNameBox.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            WorkerNameBox.Location = new Point(1406, 10);
            WorkerNameBox.Name = "WorkerNameBox";
            WorkerNameBox.Size = new Size(213, 27);
            WorkerNameBox.TabIndex = 8;
            // 
            // DueMileageText
            // 
            DueMileageText.AutoSize = true;
            DueMileageText.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            DueMileageText.Location = new Point(591, 15);
            DueMileageText.Name = "DueMileageText";
            DueMileageText.Size = new Size(113, 17);
            DueMileageText.TabIndex = 7;
            DueMileageText.Text = "Due Mileage Box";
            // 
            // textBox3
            // 
            textBox3.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox3.Location = new Point(710, 10);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(129, 27);
            textBox3.TabIndex = 6;
            // 
            // CuurentMileageText
            // 
            CuurentMileageText.AutoSize = true;
            CuurentMileageText.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            CuurentMileageText.Location = new Point(286, 15);
            CuurentMileageText.Name = "CuurentMileageText";
            CuurentMileageText.Size = new Size(107, 17);
            CuurentMileageText.TabIndex = 5;
            CuurentMileageText.Text = "Current Mileage";
            CuurentMileageText.Click += CuurentMileageText_Click;
            // 
            // CurrentMileageBox
            // 
            CurrentMileageBox.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            CurrentMileageBox.Location = new Point(399, 10);
            CurrentMileageBox.Name = "CurrentMileageBox";
            CurrentMileageBox.Size = new Size(129, 27);
            CurrentMileageBox.TabIndex = 4;
            // 
            // OilMileageText
            // 
            OilMileageText.AutoSize = true;
            OilMileageText.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            OilMileageText.Location = new Point(12, 15);
            OilMileageText.Name = "OilMileageText";
            OilMileageText.Size = new Size(79, 17);
            OilMileageText.TabIndex = 3;
            OilMileageText.Text = "Oil Mileage";
            // 
            // OilMileageBox
            // 
            OilMileageBox.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            OilMileageBox.Location = new Point(97, 10);
            OilMileageBox.Name = "OilMileageBox";
            OilMileageBox.Size = new Size(129, 27);
            OilMileageBox.TabIndex = 2;
            // 
            // panel2
            // 
            panel2.BackColor = Color.SkyBlue;
            panel2.Controls.Add(VehicleSearchButton);
            panel2.Controls.Add(label1);
            panel2.Controls.Add(VehicleSearchBox);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(1676, 47);
            panel2.TabIndex = 0;
            // 
            // VehicleSearchButton
            // 
            VehicleSearchButton.BackColor = Color.CornflowerBlue;
            VehicleSearchButton.FlatAppearance.BorderSize = 0;
            VehicleSearchButton.FlatStyle = FlatStyle.Flat;
            VehicleSearchButton.Font = new Font("Segoe UI Semibold", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            VehicleSearchButton.Location = new Point(347, 15);
            VehicleSearchButton.Name = "VehicleSearchButton";
            VehicleSearchButton.Size = new Size(115, 24);
            VehicleSearchButton.TabIndex = 2;
            VehicleSearchButton.Text = "Search Vehicle";
            VehicleSearchButton.UseVisualStyleBackColor = false;
            VehicleSearchButton.Click += VehicleSearchButton_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(12, 16);
            label1.Name = "label1";
            label1.Size = new Size(150, 17);
            label1.TabIndex = 1;
            label1.Text = "Search Vehicle Number";
            // 
            // VehicleSearchBox
            // 
            VehicleSearchBox.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            VehicleSearchBox.Location = new Point(168, 12);
            VehicleSearchBox.Name = "VehicleSearchBox";
            VehicleSearchBox.Size = new Size(173, 27);
            VehicleSearchBox.TabIndex = 0;
            // 
            // tableLayoutPanel2
            // 
            tableLayoutPanel2.ColumnCount = 3;
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            tableLayoutPanel2.Location = new Point(0, 0);
            tableLayoutPanel2.Name = "tableLayoutPanel2";
            tableLayoutPanel2.RowCount = 3;
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel2.Size = new Size(200, 100);
            tableLayoutPanel2.TabIndex = 0;
            // 
            // Billing
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1676, 916);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Billing";
            Text = "Billing";
            Load += Billing_Load;
            panel1.ResumeLayout(false);
            panel22.ResumeLayout(false);
            panel22.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)PrintInvoice).EndInit();
            ((System.ComponentModel.ISupportInitialize)JazzCashCheck).EndInit();
            ((System.ComponentModel.ISupportInitialize)ATMText).EndInit();
            ((System.ComponentModel.ISupportInitialize)Credit).EndInit();
            ((System.ComponentModel.ISupportInitialize)CashCheck).EndInit();
            tableLayoutPanel1.ResumeLayout(false);
            panel12.ResumeLayout(false);
            panel12.PerformLayout();
            panel11.ResumeLayout(false);
            panel11.PerformLayout();
            panel10.ResumeLayout(false);
            panel10.PerformLayout();
            panel9.ResumeLayout(false);
            panel9.PerformLayout();
            panel8.ResumeLayout(false);
            panel8.PerformLayout();
            panel7.ResumeLayout(false);
            panel7.PerformLayout();
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)editableList1.TextBox).EndInit();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private Panel panel1;
        private Panel panel2;
        private Label label1;
        private TextBox VehicleSearchBox;
        private Panel panel3;
        private Button VehicleSearchButton;
        private Label WorkerNameText;
        private TextBox WorkerNameBox;
        private Label DueMileageText;
        private TextBox textBox3;
        private Label CuurentMileageText;
        private TextBox CurrentMileageBox;
        private Label OilMileageText;
        private TextBox OilMileageBox;
        private Panel panel4;
        private Label PrevBalanaceText;
        private TextBox PrevBalanceBox;
        private Label CellNumberText;
        private TextBox textBox2;
        private Label CustomerNameText;
        private TextBox textBox4;
        private Panel panel5;
        private Label ProductNameText;
        private TextBox ProductNameBox;
        private Label ProductBarcodeText;
        private TextBox ProductBarcodeBox;
        private TableLayoutPanel tableLayoutPanel2;
        private TableLayoutPanel tableLayoutPanel1;
        private Panel panel6;
        private Panel panel12;
        private Panel panel11;
        private Panel panel10;
        private Panel panel9;
        private Panel panel8;
        private Panel panel7;
        private Label BarcodeText;
        private Label TotalPriceText;
        private Label PricePerUnitText;
        private Label QuantityPerUnitText;
        private Label QuantityinStock;
        private Label ProductName;
        private Label hashText;
        private Panel panel22;
        private TextBox NetAmountBox;
        private Label NetAmountText;
        private TextBox DiscountBox;
        private Label DiscountText;
        private TextBox TotalAmountBox;
        private Label TotalAmountText;
        private TextBox BalanceBox;
        private Label BalanceText;
        private TextBox ReceivedBox;
        private Label RecievedText;
        private Button SearchCustomerButton;
        private Button CheckoutButton;
        private Syncfusion.Windows.Forms.Tools.CheckBoxAdv ATMText;
        private Syncfusion.Windows.Forms.Tools.CheckBoxAdv Credit;
        private Syncfusion.Windows.Forms.Tools.AutoLabel ModeOfPaymentText;
        private Syncfusion.Windows.Forms.Tools.CheckBoxAdv CashCheck;
        private Syncfusion.Windows.Forms.Tools.CheckBoxAdv JazzCashCheck;
        private Syncfusion.Windows.Forms.Tools.CheckBoxAdv PrintInvoice;
        private Button CalculatorButton;
        private Syncfusion.Calculate.CalculateConfig calculateConfig1;
        private Syncfusion.Windows.Forms.Tools.EditableList editableList1;
        private Button additemtotable;
        private Label qtylable;
        private TextBox itemquantity;
    }
}