﻿namespace Medley_Car_Care
{
    partial class Add_Account
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            gridListControl1 = new Syncfusion.Windows.Forms.Grid.GridListControl();
            ((System.ComponentModel.ISupportInitialize)gridListControl1).BeginInit();
            SuspendLayout();
            // 
            // gridListControl1
            // 
            gridListControl1.BackColor = Color.GhostWhite;
            gridListControl1.BorderStyle = BorderStyle.Fixed3D;
            gridListControl1.ItemHeight = 17;
            gridListControl1.Location = new Point(335, 194);
            gridListControl1.Name = "gridListControl1";
            gridListControl1.Properties.BackgroundColor = SystemColors.Window;
            gridListControl1.SelectedIndex = -1;
            gridListControl1.Size = new Size(717, 464);
            gridListControl1.TabIndex = 0;
            gridListControl1.ThemeStyle.HorizontalScrollBarStyle.ArrowButtonBackColor = Color.FromArgb(255, 255, 255);
            gridListControl1.ThemeStyle.HorizontalScrollBarStyle.ArrowButtonBorderColor = Color.FromArgb(225, 225, 225);
            gridListControl1.ThemeStyle.HorizontalScrollBarStyle.ArrowButtonDisabledBackColor = Color.FromArgb(225, 225, 225);
            gridListControl1.ThemeStyle.HorizontalScrollBarStyle.ArrowButtonDisabledBorderColor = Color.FromArgb(210, 210, 210);
            gridListControl1.ThemeStyle.HorizontalScrollBarStyle.ArrowButtonHoverBackColor = Color.FromArgb(114, 114, 114);
            gridListControl1.ThemeStyle.HorizontalScrollBarStyle.ArrowButtonHoverBorderColor = Color.FromArgb(94, 94, 94);
            gridListControl1.ThemeStyle.HorizontalScrollBarStyle.ArrowButtonPressedBackColor = Color.FromArgb(225, 225, 225);
            gridListControl1.ThemeStyle.HorizontalScrollBarStyle.ArrowButtonPressedBorderColor = Color.FromArgb(150, 150, 150);
            gridListControl1.ThemeStyle.HorizontalScrollBarStyle.ScrollBarBackColor = Color.FromArgb(225, 225, 225);
            gridListControl1.ThemeStyle.HorizontalScrollBarStyle.ThumbBorderColor = Color.FromArgb(171, 171, 171);
            gridListControl1.ThemeStyle.HorizontalScrollBarStyle.ThumbColor = Color.FromArgb(255, 255, 255);
            gridListControl1.ThemeStyle.HorizontalScrollBarStyle.ThumbDisabledBorderColor = Color.FromArgb(210, 210, 210);
            gridListControl1.ThemeStyle.HorizontalScrollBarStyle.ThumbDisabledColor = Color.FromArgb(225, 225, 225);
            gridListControl1.ThemeStyle.HorizontalScrollBarStyle.ThumbHoverBorderColor = Color.FromArgb(171, 171, 171);
            gridListControl1.ThemeStyle.HorizontalScrollBarStyle.ThumbHoverColor = Color.FromArgb(197, 197, 197);
            gridListControl1.ThemeStyle.HorizontalScrollBarStyle.ThumbPressedBorderColor = Color.FromArgb(150, 150, 150);
            gridListControl1.ThemeStyle.HorizontalScrollBarStyle.ThumbPressedColor = Color.FromArgb(197, 197, 197);
            gridListControl1.ThemeStyle.VerticalScrollBarStyle.ArrowButtonBackColor = Color.FromArgb(255, 255, 255);
            gridListControl1.ThemeStyle.VerticalScrollBarStyle.ArrowButtonBorderColor = Color.FromArgb(225, 225, 225);
            gridListControl1.ThemeStyle.VerticalScrollBarStyle.ArrowButtonDisabledBackColor = Color.FromArgb(225, 225, 225);
            gridListControl1.ThemeStyle.VerticalScrollBarStyle.ArrowButtonDisabledBorderColor = Color.FromArgb(210, 210, 210);
            gridListControl1.ThemeStyle.VerticalScrollBarStyle.ArrowButtonHoverBackColor = Color.FromArgb(114, 114, 114);
            gridListControl1.ThemeStyle.VerticalScrollBarStyle.ArrowButtonHoverBorderColor = Color.FromArgb(94, 94, 94);
            gridListControl1.ThemeStyle.VerticalScrollBarStyle.ArrowButtonPressedBackColor = Color.FromArgb(225, 225, 225);
            gridListControl1.ThemeStyle.VerticalScrollBarStyle.ArrowButtonPressedBorderColor = Color.FromArgb(150, 150, 150);
            gridListControl1.ThemeStyle.VerticalScrollBarStyle.ScrollBarBackColor = Color.FromArgb(225, 225, 225);
            gridListControl1.ThemeStyle.VerticalScrollBarStyle.ThumbBorderColor = Color.FromArgb(171, 171, 171);
            gridListControl1.ThemeStyle.VerticalScrollBarStyle.ThumbColor = Color.FromArgb(255, 255, 255);
            gridListControl1.ThemeStyle.VerticalScrollBarStyle.ThumbDisabledBorderColor = Color.FromArgb(210, 210, 210);
            gridListControl1.ThemeStyle.VerticalScrollBarStyle.ThumbDisabledColor = Color.FromArgb(225, 225, 225);
            gridListControl1.ThemeStyle.VerticalScrollBarStyle.ThumbHoverBorderColor = Color.FromArgb(171, 171, 171);
            gridListControl1.ThemeStyle.VerticalScrollBarStyle.ThumbHoverColor = Color.FromArgb(197, 197, 197);
            gridListControl1.ThemeStyle.VerticalScrollBarStyle.ThumbPressedBorderColor = Color.FromArgb(150, 150, 150);
            gridListControl1.ThemeStyle.VerticalScrollBarStyle.ThumbPressedColor = Color.FromArgb(197, 197, 197);
            gridListControl1.TopIndex = 0;
            // 
            // Add_Account
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.GhostWhite;
            Controls.Add(gridListControl1);
            Name = "Add_Account";
            Size = new Size(1678, 919);
            ((System.ComponentModel.ISupportInitialize)gridListControl1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Syncfusion.Windows.Forms.Grid.GridListControl gridListControl1;
    }
}
